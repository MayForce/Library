package sample;

public class Audiovisual extends Item {

    public Audiovisual(String author, String title, String keywords, double price) {
        super(author, title, keywords, price);
    }
}
