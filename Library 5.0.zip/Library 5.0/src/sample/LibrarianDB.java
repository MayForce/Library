package sample;

import java.util.Hashtable;

public class LibrarianDB {
    public Hashtable<String, Librarian> librarians;

    public LibrarianDB(){
        librarians = new Hashtable<>();
    }
}
